
# LoopBar [![Awesome](https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg)](https://github.com/sindresorhus/awesome) <img src="https://www.cleveroad.com/public/comercial/label-android.svg" height="19"> <a href="https://www.cleveroad.com/?utm_source=github&utm_medium=label&utm_campaign=contacts"><img src="https://www.cleveroad.com/public/comercial/label-cleveroad.svg" height="19"></a>
![Header image](/images/header.png)

## LoopBar - Tab Bar with Infinite Scrolling for Android by Cleveroad

## Changelog

Version | Changes
---     | ---
v.1.1.1 | <ul><li>Added ability to change scroll mode</li><li>Fixed overlay feature</li><li>Updated start position in Infinite scroll mode</li><li>Removed unused dependencies</li><li>Updated versions of dependencies</li><li>unused or old methods were marked as deprecated</li><li>Added auto resize selector logic for different size of items support</li><li>Removed start and end shadows</li></ul>
v.1.1.2 | <ul><li>Added SDK v.15 support</li><ul>
v.1.1.3 | <ul><li>Fixed crashes with empty adapter</li><li>Fixed crashes without adapter</li><ul>

<br />
