package com.cleveroad.loopbar.adapter;

public interface IOperationItem {

    boolean isVisible();

    void setVisible(boolean isVisible);

}
