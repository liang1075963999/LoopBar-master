package com.cleveroad.sample;

import android.support.v4.app.Fragment;

public interface IFragmentReplacer {
    void replaceFragment(Fragment fragment);
}
